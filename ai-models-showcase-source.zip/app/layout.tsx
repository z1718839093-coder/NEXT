import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "AI Models China - 中国AI大模型全景图谱",
  description: "探索国内领先的AI大语言模型，了解DeepSeek、Qwen、文心一言、智谱、Kimi、豆包、讯飞星火、百川等主流大模型的特色与优势",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="zh-CN" className="scroll-smooth">
      <body className="bg-[#0a0a0a] text-white antialiased">{children}</body>
    </html>
  );
}
