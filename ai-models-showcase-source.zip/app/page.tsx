import Header from '@/components/Header';
import Hero from '@/components/Hero';
import LLMIntro from '@/components/LLMIntro';
import ModelArchitecture from '@/components/ModelArchitecture';
import AgentIntro from '@/components/AgentIntro';
import AgentArchitecture from '@/components/AgentArchitecture';
import ModelGrid from '@/components/ModelGrid';
import ModelCompare from '@/components/ModelCompare';
import ModelTimeline from '@/components/ModelTimeline';
import GlobalModelGrid from '@/components/GlobalModelGrid';
import GlobalModelCompare from '@/components/GlobalModelCompare';
import AgentGrid from '@/components/AgentGrid';
import AgentCompare from '@/components/AgentCompare';
import AgentTimeline from '@/components/AgentTimeline';
import GlobalAgentGrid from '@/components/GlobalAgentGrid';
import GlobalAgentCompare from '@/components/GlobalAgentCompare';
import Footer from '@/components/Footer';

export default function Home() {
  return (
    <main className="min-h-screen bg-[#0a0a0a]">
      <Header />
      <Hero />
      <LLMIntro />
      <ModelArchitecture />
      <AgentIntro />
      <AgentArchitecture />
      <ModelGrid />
      <ModelCompare />
      <ModelTimeline />
      <GlobalModelGrid />
      <GlobalModelCompare />
      <AgentGrid />
      <AgentCompare />
      <AgentTimeline />
      <GlobalAgentGrid />
      <GlobalAgentCompare />
      <Footer />
    </main>
  );
}
