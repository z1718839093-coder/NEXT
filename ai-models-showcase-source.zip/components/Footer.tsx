'use client';

import { motion } from 'framer-motion';

export default function Footer() {
  return (
    <motion.footer
      initial={{ opacity: 0 }}
      whileInView={{ opacity: 1 }}
      viewport={{ once: true }}
      className="relative py-16 px-4 border-t border-purple-500/20"
    >
      {/* 背景装饰 */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute inset-0 bg-[linear-gradient(rgba(139,92,246,0.02)_1px,transparent_1px),linear_gradient(90deg,rgba(139,92,246,0.02)_1px,transparent_1px)] bg-[size:30px_30px]" />
      </div>

      <div className="max-w-7xl mx-auto relative">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10 mb-12">
          {/* Brand */}
          <div>
            <div className="flex items-center space-x-3 mb-4">
              <div className="relative">
                <div className="absolute -inset-1 bg-gradient-to-br from-purple-500 to-cyan-500 rounded-lg blur opacity-50" />
                <div className="relative w-10 h-10 rounded-lg bg-gradient-to-br from-purple-600 to-cyan-600 flex items-center justify-center border border-purple-400/50">
                  <span className="text-white font-bold text-sm font-mono">AI</span>
                </div>
              </div>
              <span className="text-white font-semibold text-lg font-mono tracking-wider">
                <span className="text-purple-400">&gt;</span> MODEL<span className="text-cyan-400">S</span>_CHINA
              </span>
            </div>
            <p className="text-gray-400 text-sm font-mono leading-relaxed">
              {'>'} 中国AI大模型全景知识库<br/>
              {'>'} 助力了解最前沿的人工智能技术发展
            </p>
          </div>

          {/* Data Sources */}
          <div>
            <h4 className="text-white font-semibold mb-4 font-mono">
              <span className="text-purple-400">&gt;</span> DATA SOURCES
            </h4>
            <ul className="space-y-2">
              {[
                { name: '模型官网', desc: '各模型官方网站' },
                { name: 'HuggingFace', desc: '开源模型平台' },
                { name: 'Papers With Code', desc: '学术论文' },
                { name: 'ITBear', desc: 'AI资讯采集' },
                { name: 'AI产品榜', desc: '国内AI产品收录' },
              ].map((source) => (
                <li key={source.name} className="flex items-start gap-2">
                  <span className="text-purple-500/50 text-xs mt-1">●</span>
                  <span className="text-gray-400 text-sm">
                    <span className="text-purple-300">{source.name}</span>
                    <span className="text-gray-500"> - {source.desc}</span>
                  </span>
                </li>
              ))}
            </ul>
          </div>

          {/* Disclaimer */}
          <div>
            <h4 className="text-white font-semibold mb-4 font-mono">
              <span className="text-purple-400">&gt;</span> DISCLAIMER
            </h4>
            <div className="space-y-3">
              <p className="text-gray-400 text-xs font-mono leading-relaxed">
                {'>'} 本站点信息仅供参考学习<br/>
                {'>'} 各模型实际能力可能随版本更新而变化<br/>
                {'>'} 不保证信息的准确性和时效性
              </p>
              <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-purple-500/10 border border-purple-500/20 rounded">
                <span className="w-2 h-2 bg-cyan-500 rounded-full animate-pulse" />
                <span className="text-cyan-400 text-xs font-mono">
                  LAST UPDATE: 2025.05
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Quick Links */}
        <div className="mb-10 p-6 bg-black/30 border border-purple-500/20 rounded-xl">
          <h4 className="text-white font-semibold mb-4 font-mono text-center">
            <span className="text-purple-400">///</span> QUICK NAV <span className="text-purple-400">///</span>
          </h4>
          <div className="flex flex-wrap justify-center gap-2">
            {[
              { href: '#llm-intro', label: '[科普专栏]' },
              { href: '#model-arch', label: '[模型架构]' },
              { href: '#agent-intro', label: '[Agent介绍]' },
              { href: '#skill-intro', label: '[Skill介绍]' },
              { href: '#models', label: '[国内模型]' },
              { href: '#global-models', label: '[全球模型]' },
              { href: '#agents', label: '[国内Agent]' },
              { href: '#global-agents', label: '[全球Agent]' },
              { href: '#timeline', label: '[时间线]' },
              { href: '#compare', label: '[模型对比]' },
            ].map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="text-purple-300 hover:text-white hover:bg-purple-500/20 px-3 py-1.5 rounded text-sm font-mono transition-all"
              >
                {link.label}
              </a>
            ))}
          </div>
        </div>

        {/* Bottom */}
        <div className="pt-6 border-t border-purple-500/20 text-center">
          <p className="text-gray-500 text-xs font-mono">
            &copy; {new Date().getFullYear()} AI MODELS CHINA. ALL RIGHTS RESERVED.
          </p>
        </div>
      </div>
    </motion.footer>
  );
}