'use client';

import { motion } from 'framer-motion';

const timeline = [
  { date: '2023.03', title: '文心一言', desc: '百度率先发布国内首个大语言模型', color: '#2932E1' },
  { date: '2023.03', title: '智谱GLM', desc: 'GLM系列开源，学术界广泛关注', color: '#00D4AA' },
  { date: '2023.04', title: '通义千问', desc: '阿里发布Qwen系列，快速迭代', color: '#FF6A00' },
  { date: '2023.04', title: '天工 & 商汤', desc: '昆仑万维和商汤入局大模型赛道', color: '#2563EB' },
  { date: '2023.05', title: '讯飞星火', desc: '科大讯飞以语音交互为特色入局', color: '#FF8C00' },
  { date: '2023.09', title: '腾讯混元', desc: '腾讯发布混元大模型', color: '#07C160' },
  { date: '2023.10', title: 'Kimi', desc: '月之暗面主打超长上下文处理', color: '#7C3AED' },
  { date: '2024.01', title: 'DeepSeek-V2', desc: 'MoE架构创新，性价比轰动业界', color: '#4F46E5' },
  { date: '2024.02', title: 'MiniCPM', desc: '面壁智能发布端侧小模型', color: '#059669' },
  { date: '2024.03', title: '阶跃星辰', desc: 'Step-2多模态能力领跑', color: '#E11D48' },
  { date: '2024.05', title: '豆包升级', desc: '字节跳动发力多模态与创意', color: '#FE2C55' },
  { date: '2024.12', title: 'DeepSeek-V3', desc: '671B MoE，开源新巅峰', color: '#4F46E5' },
  { date: '2025.01', title: 'DeepSeek-R1', desc: '推理模型震撼全球', color: '#4F46E5' },
  { date: '2025.04', title: '小米MiMo', desc: '7B参数实现强推理能力', color: '#FF6900' },
];

export default function ModelTimeline() {
  return (
    <section id="timeline" className="relative py-24 px-4">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            <span className="bg-gradient-to-r from-white to-gray-400 bg-clip-text text-transparent">
              发展历程
            </span>
          </h2>
          <p className="text-gray-400 text-lg">
            中国大模型的崛起之路（2023 - 2025）
          </p>
        </motion.div>

        {/* Horizontal scrollable timeline */}
        <div className="relative overflow-x-auto pb-8 -mx-4 px-4">
          <div className="relative min-w-max">
            {/* Horizontal line */}
            <div className="absolute top-[21px] left-0 right-0 h-[2px] bg-gradient-to-r from-purple-500 via-blue-500 to-cyan-500" />

            {/* Timeline items */}
            <div className="flex gap-0">
              {timeline.map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.08 }}
                  className="relative flex flex-col items-center w-[140px] flex-shrink-0"
                >
                  {/* Dot */}
                  <motion.div
                    whileInView={{ scale: [0, 1.3, 1] }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.08 + 0.2 }}
                    className="w-[42px] h-[42px] rounded-full flex items-center justify-center mb-4 relative z-10"
                    style={{ backgroundColor: item.color + '20' }}
                  >
                    <div
                      className="w-3 h-3 rounded-full"
                      style={{ backgroundColor: item.color }}
                    />
                  </motion.div>

                  {/* Content below line */}
                  <div className="text-center px-2">
                    <div className="text-xs text-gray-500 mb-1 font-mono">{item.date}</div>
                    <h3 className="text-sm font-semibold text-white mb-1">{item.title}</h3>
                    <p className="text-xs text-gray-400 leading-relaxed">{item.desc}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>

        {/* Scroll hint */}
        <div className="text-center">
          <motion.div
            animate={{ x: [0, 10, 0] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="inline-flex items-center gap-2 text-xs text-gray-500"
          >
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
            </svg>
            横向滚动查看更多
          </motion.div>
        </div>
      </div>
    </section>
  );
}
