'use client';

import { motion } from 'framer-motion';
import { agents } from '@/data/agents';
import AgentCard from './AgentCard';

export default function AgentGrid() {
  return (
    <section id="agents" className="relative py-24 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            <span className="bg-gradient-to-r from-white to-gray-400 bg-clip-text text-transparent">
              AI Agent 平台
            </span>
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            基于大模型构建的智能体平台，让 AI 能力以更低门槛落地到实际业务场景
          </p>
        </motion.div>

        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {agents.map((agent, index) => (
            <AgentCard key={agent.id} agent={agent} index={index} />
          ))}
        </div>
      </div>

      {/* Background decoration */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-gradient-to-r from-orange-500/5 to-purple-500/5 rounded-full blur-3xl -z-10" />
    </section>
  );
}
