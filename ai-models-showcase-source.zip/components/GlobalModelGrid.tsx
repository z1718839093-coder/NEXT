'use client';

import { motion } from 'framer-motion';
import { globalModels } from '@/data/globalModels';
import GlobalModelCard from './GlobalModelCard';

export default function GlobalModelGrid() {
  return (
    <section id="global-models" className="relative py-24 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            <span className="bg-gradient-to-r from-white to-gray-400 bg-clip-text text-transparent">
              全球主流大模型
            </span>
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            OpenAI、Anthropic、Google、Meta 等全球顶尖 AI 实验室的大模型产品
          </p>
        </motion.div>

        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {globalModels.map((model, index) => (
            <GlobalModelCard key={model.id} model={model} index={index} />
          ))}
        </div>
      </div>

      {/* Background decoration */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-gradient-to-r from-green-500/5 to-blue-500/5 rounded-full blur-3xl -z-10" />
    </section>
  );
}
