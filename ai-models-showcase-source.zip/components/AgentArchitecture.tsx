'use client';

import { motion } from 'framer-motion';

const agentTypes = [
  {
    name: '自主型 Agent',
    en: 'Autonomous Agent',
    color: '#7C3AED',
    desc: 'Agent 独立感知环境、制定计划并执行行动，可在最少人工干预下完成复杂任务。通过反思循环不断自我优化。',
    features: ['自主决策与行动', 'ReAct 推理循环', '自我反思与纠错', '适应开放域任务'],
    examples: 'AutoGPT、AgentGPT、扣子 Bot',
  },
  {
    name: '工作流 Agent',
    en: 'Workflow Agent',
    color: '#06B6D4',
    desc: '通过可视化流程编排，将多个步骤串联为确定性工作流。每步可由 LLM 节点、工具节点或条件分支组成。',
    features: ['流程可视化编排', '确定性执行路径', '易于调试与监控', '适合标准化业务'],
    examples: 'Dify 工作流、Coze 流程、FastGPT',
  },
  {
    name: '多智能体协作',
    en: 'Multi-Agent',
    color: '#10B981',
    desc: '多个 Agent 协同工作，各司其职（如规划者、执行者、审核者），通过通信协议共享信息，完成单一 Agent 难以完成的复杂任务。',
    features: ['分工协作', '角色化设计', '群体智能涌现', '适合复杂决策场景'],
    examples: 'CrewAI、MetaGPT、AutoGen',
  },
];

const platformComparison = [
  { platform: 'Coze (扣子)', type: '工作流 + 自主型', core: '插件生态、多渠道发布', scene: '客服/内容/效率工具', deploy: 'SaaS' },
  { platform: 'Dify', type: '工作流 + RAG', core: '开源、Prompt IDE', scene: '企业级 AI 应用', deploy: '自部署 / SaaS' },
  { platform: 'FastGPT', type: '工作流 + RAG', core: '知识库问答、一键部署', scene: '智能客服/知识库', deploy: '自部署' },
  { platform: '阿里百炼', type: '全栈型', core: '模型广场、企业级部署', scene: '企业 AI 中台', deploy: '阿里云' },
  { platform: '腾讯元器', type: '自主型', core: '微信/QQ 生态集成', scene: 'C 端智能体', deploy: 'SaaS' },
  { platform: 'RAGFlow', type: 'RAG 引擎', core: '深度文档解析、可溯源', scene: '文档问答/知识管理', deploy: '自部署' },
  { platform: 'FlowiseAI', type: '工作流', core: 'LangChain 可视化', scene: '快速原型验证', deploy: '自部署' },
  { platform: '魔搭 Agent', type: '工具型', core: '开源模型社区', scene: '模型调用/开发者', deploy: 'SaaS' },
];

export default function AgentArchitecture() {
  return (
    <section id="agent-arch" className="relative py-24 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            <span className="bg-gradient-to-r from-white to-gray-400 bg-clip-text text-transparent">
              Agent AI 架构与区别
            </span>
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            不同 Agent 架构适用于不同场景，选择合适的类型至关重要
          </p>
        </motion.div>

        {/* Agent type cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
          {agentTypes.map((agent, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.15 }}
              className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-8 hover:border-white/20 transition-all duration-300"
            >
              <div className="flex items-center gap-3 mb-2">
                <div
                  className="w-3 h-3 rounded-full"
                  style={{ backgroundColor: agent.color }}
                />
                <h3 className="text-lg font-bold text-white">{agent.name}</h3>
              </div>
              <div className="text-xs text-gray-500 mb-4">{agent.en}</div>
              <p className="text-sm text-gray-400 mb-6 leading-relaxed">{agent.desc}</p>
              <ul className="space-y-2 mb-6">
                {agent.features.map((f, i) => (
                  <li key={i} className="flex items-center gap-2 text-sm text-gray-300">
                    <div
                      className="w-1.5 h-1.5 rounded-full flex-shrink-0"
                      style={{ backgroundColor: agent.color }}
                    />
                    {f}
                  </li>
                ))}
              </ul>
              <div className="pt-4 border-t border-white/5">
                <div className="text-xs text-gray-500 mb-1">代表平台</div>
                <div className="text-sm text-gray-300">{agent.examples}</div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Platform comparison table */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="overflow-x-auto"
        >
          <table className="w-full min-w-[700px]">
            <thead>
              <tr className="border-b border-white/10">
                <th className="text-left py-4 px-6 text-gray-400 font-medium">平台</th>
                <th className="text-center py-4 px-4 text-gray-400 font-medium">Agent 类型</th>
                <th className="text-center py-4 px-4 text-gray-400 font-medium">核心能力</th>
                <th className="text-center py-4 px-4 text-gray-400 font-medium">适用场景</th>
                <th className="text-center py-4 px-4 text-gray-400 font-medium">部署方式</th>
              </tr>
            </thead>
            <tbody>
              {platformComparison.map((item, index) => (
                <motion.tr
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.05 }}
                  className="border-b border-white/5 hover:bg-white/5 transition-colors"
                >
                  <td className="py-3 px-6 text-white font-medium">{item.platform}</td>
                  <td className="py-3 px-4 text-center">
                    <span className="px-2.5 py-1 bg-cyan-500/10 text-cyan-300 rounded-lg text-xs font-medium">
                      {item.type}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-center text-gray-300 text-sm">{item.core}</td>
                  <td className="py-3 px-4 text-center text-gray-400 text-sm">{item.scene}</td>
                  <td className="py-3 px-4 text-center text-gray-300 text-sm">{item.deploy}</td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </motion.div>
      </div>

      <div className="absolute top-1/3 right-0 w-[500px] h-[500px] bg-green-500/5 rounded-full blur-3xl -z-10" />
    </section>
  );
}
