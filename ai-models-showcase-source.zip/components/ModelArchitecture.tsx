'use client';

import { motion } from 'framer-motion';

const archTypes = [
  {
    name: 'Dense Transformer',
    color: '#7C3AED',
    desc: '所有参数在每次推理中全部激活。模型容量大，能力强，但计算成本高。',
    features: ['所有参数参与计算', '表达能力强', '推理成本随参数线性增长', '适合中小规模模型'],
    examples: 'GPT-4、Llama 3、Qwen Dense',
  },
  {
    name: 'MoE (混合专家)',
    color: '#06B6D4',
    desc: '将模型划分为多个"专家"，每次输入只激活其中一小部分。总参数量大但计算量可控。',
    features: ['稀疏激活，效率高', '总参数可达万亿级', '推理时只激活部分专家', '适合超大规模模型'],
    examples: 'DeepSeek-V3、Mixtral、Qwen-MoE',
  },
];

const modelComparison = [
  { model: 'DeepSeek-V3', arch: 'MoE', params: '671B', context: '128K', open: '开源', scene: '代码/推理/通用' },
  { model: 'Qwen 3', arch: 'Dense/MoE', params: '0.6B~235B', context: '128K', open: '开源', scene: '多模态/工具调用' },
  { model: '文心一言 4.5', arch: 'Dense', params: '300B+', context: '128K', open: '闭源', scene: '中文理解/知识增强' },
  { model: '智谱 GLM-4', arch: 'Dense', params: '130B', context: '128K', open: '开源', scene: 'Agent/代码/多模态' },
  { model: 'Kimi K2', arch: 'MoE', params: '未公开', context: '200万字', open: '闭源', scene: '长文本/文档解析' },
  { model: '混元', arch: 'MoE', params: '389B', context: '256K', open: '开源', scene: '视频生成/多模态' },
  { model: 'MiniCPM', arch: 'Dense', params: '2B', context: '32K', open: '开源', scene: '端侧部署/高效推理' },
  { model: 'MiMo', arch: 'Dense', params: '7B', context: '32K', open: '开源', scene: '数学推理/代码' },
];

export default function ModelArchitecture() {
  return (
    <section id="model-arch" className="relative py-24 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            <span className="bg-gradient-to-r from-white to-gray-400 bg-clip-text text-transparent">
              大模型架构与区别
            </span>
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            不同架构设计决定了模型的能力上限与计算效率
          </p>
        </motion.div>

        {/* Architecture comparison */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-16">
          {archTypes.map((arch, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: index === 0 ? -40 : 40 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-8 hover:border-white/20 transition-all duration-300"
            >
              <div className="flex items-center gap-3 mb-4">
                <div
                  className="w-3 h-3 rounded-full"
                  style={{ backgroundColor: arch.color }}
                />
                <h3 className="text-xl font-bold text-white">{arch.name}</h3>
              </div>
              <p className="text-gray-400 mb-6">{arch.desc}</p>
              <ul className="space-y-3 mb-6">
                {arch.features.map((f, i) => (
                  <li key={i} className="flex items-center gap-3 text-sm text-gray-300">
                    <div
                      className="w-1.5 h-1.5 rounded-full flex-shrink-0"
                      style={{ backgroundColor: arch.color }}
                    />
                    {f}
                  </li>
                ))}
              </ul>
              <div className="pt-4 border-t border-white/5">
                <div className="text-xs text-gray-500 mb-2">代表模型</div>
                <div className="text-sm text-gray-300">{arch.examples}</div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Model comparison table */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="overflow-x-auto"
        >
          <table className="w-full min-w-[700px]">
            <thead>
              <tr className="border-b border-white/10">
                <th className="text-left py-4 px-6 text-gray-400 font-medium">模型</th>
                <th className="text-center py-4 px-4 text-gray-400 font-medium">架构</th>
                <th className="text-center py-4 px-4 text-gray-400 font-medium">参数量级</th>
                <th className="text-center py-4 px-4 text-gray-400 font-medium">上下文</th>
                <th className="text-center py-4 px-4 text-gray-400 font-medium">开源</th>
                <th className="text-center py-4 px-4 text-gray-400 font-medium">核心场景</th>
              </tr>
            </thead>
            <tbody>
              {modelComparison.map((item, index) => (
                <motion.tr
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.05 }}
                  className="border-b border-white/5 hover:bg-white/5 transition-colors"
                >
                  <td className="py-3 px-6 text-white font-medium">{item.model}</td>
                  <td className="py-3 px-4 text-center">
                    <span className="px-2.5 py-1 bg-purple-500/10 text-purple-300 rounded-lg text-xs font-medium">
                      {item.arch}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-center text-gray-300 text-sm">{item.params}</td>
                  <td className="py-3 px-4 text-center text-gray-300 text-sm">{item.context}</td>
                  <td className="py-3 px-4 text-center">
                    <span className={`text-xs font-medium ${item.open === '开源' ? 'text-green-400' : 'text-orange-400'}`}>
                      {item.open}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-center text-gray-400 text-sm">{item.scene}</td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </motion.div>
      </div>

      <div className="absolute top-1/3 left-0 w-[500px] h-[500px] bg-cyan-500/5 rounded-full blur-3xl -z-10" />
    </section>
  );
}
