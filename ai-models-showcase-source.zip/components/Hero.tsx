'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { models } from '@/data/models';
import { globalModels } from '@/data/globalModels';
import { agents } from '@/data/agents';
import { globalAgents } from '@/data/globalAgents';

// 统计数据
const stats = [
  { label: '国内模型', count: models.length, icon: '🔍' },
  { label: '全球模型', count: globalModels.length, icon: '🌐' },
  { label: 'Agent 平台', count: agents.length + globalAgents.length, icon: '⚡' },
  { label: '技术专题', count: 8, icon: '📚' },
];

// 热门搜索标签
const hotSearchTags = [
  { label: 'DeepSeek', type: 'model' },
  { label: 'GPT-4', type: 'global' },
  { label: 'Claude', type: 'global' },
  { label: 'Kimi', type: 'model' },
  { label: '长文本', type: 'feature' },
  { label: 'Agent', type: 'agent' },
  { label: '多模态', type: 'feature' },
  { label: '开源', type: 'feature' },
];

// 里程碑数据
const milestones = [
  { year: '2023.03', event: 'GPT-4 发布', icon: '🚀' },
  { year: '2023.04', event: '文心一言发布', icon: '🔍' },
  { year: '2023.10', event: 'Kimi 发布', icon: '🌙' },
  { year: '2024.12', event: 'DeepSeek-V3', icon: '💎' },
  { year: '2025', event: 'Agent，元年来临', icon: '⚡' },
];

// 导航分类
const navCategories = [
  {
    id: 'learn',
    icon: '📖',
    label: '学习指南',
    desc: '从零开始的 AI 学习路径',
    href: '#llm-intro',
    color: 'from-purple-500 to-pink-500',
  },
  {
    id: 'china',
    icon: '🔍',
    label: '国产大模型',
    desc: `${models.length}+ 款主流模型`,
    href: '#models',
    color: 'from-blue-500 to-cyan-500',
  },
  {
    id: 'global',
    icon: '🌐',
    label: '全球模型',
    desc: `${globalModels.length}+ 款国际模型`,
    href: '#global-models',
    color: 'from-green-500 to-emerald-500',
  },
  {
    id: 'agent',
    icon: '🤖',
    label: 'Agent 平台',
    desc: `${agents.length + globalAgents.length}+ 智能体平台`,
    href: '#agents',
    color: 'from-orange-500 to-amber-500',
  },
];

// 快捷功能
const quickActions = [
  { icon: '⚖️', label: '模型对比', href: '#compare' },
  { icon: '📅', label: '发展历程', href: '#timeline' },
  { icon: '🏆', label: '能力排行', href: '#rank' },
];

// 数字滚动动画组件
function AnimatedNumber({ value }: { value: number }) {
  const [displayValue, setDisplayValue] = useState(0);

  useEffect(() => {
    const duration = 1000;
    const steps = 30;
    const increment = value / steps;
    let current = 0;

    const timer = setInterval(() => {
      current += increment;
      if (current >= value) {
        setDisplayValue(value);
        clearInterval(timer);
      } else {
        setDisplayValue(Math.floor(current));
      }
    }, duration / steps);

    return () => clearInterval(timer);
  }, [value]);

  return <span>{displayValue}</span>;
}

// 赛博朋克网格背景组件
function CyberGrid() {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {/* 网格线 */}
      <div className="absolute inset-0"
        style={{
          backgroundImage: `
            linear-gradient(to right, rgba(139, 92, 246, 0.03) 1px, transparent 1px),
            linear-gradient(to bottom, rgba(139, 92, 246, 0.03) 1px, transparent 1px)
          `,
          backgroundSize: '50px 50px',
        }}
      />
      {/* 扫描线 */}
      <motion.div
        className="absolute left-0 w-full h-0.5 bg-gradient-to-r from-transparent via-purple-500/50 to-transparent"
        animate={{ top: ['0%', '100%'] }}
        transition={{ duration: 3, repeat: Infinity, ease: 'linear' }}
      />
    </div>
  );
}

// 预定义粒子位置（避免渲染时随机）
const particlePositions = [
  { x: '10%', y: '20%', dur: 3, delay: 0 },
  { x: '25%', y: '45%', dur: 4, delay: 1 },
  { x: '40%', y: '15%', dur: 2.5, delay: 0.5 },
  { x: '55%', y: '60%', dur: 3.5, delay: 1.5 },
  { x: '70%', y: '30%', dur: 4, delay: 0.2 },
  { x: '85%', y: '75%', dur: 3, delay: 0.8 },
  { x: '15%', y: '80%', dur: 4.5, delay: 1.2 },
  { x: '30%', y: '65%', dur: 2.8, delay: 0.3 },
  { x: '60%', y: '40%', dur: 3.2, delay: 1 },
  { x: '75%', y: '55%', dur: 3.8, delay: 0.6 },
  { x: '90%', y: '25%', dur: 4.2, delay: 1.8 },
  { x: '20%', y: '50%', dur: 2.6, delay: 0.4 },
  { x: '45%', y: '85%', dur: 3.6, delay: 1.4 },
  { x: '65%', y: '10%', dur: 4.1, delay: 0.9 },
  { x: '80%', y: '70%', dur: 3.4, delay: 1.6 },
  { x: '35%', y: '35%', dur: 2.9, delay: 0.7 },
  { x: '50%', y: '90%', dur: 4.3, delay: 1.1 },
  { x: '95%', y: '50%', dur: 3.1, delay: 0.5 },
  { x: '5%', y: '65%', dur: 3.7, delay: 1.3 },
  { x: '92%', y: '12%', dur: 2.7, delay: 0.15 },
];

// 浮动粒子组件
function FloatingParticles() {
  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden">
      {particlePositions.map((p, i) => (
        <motion.div
          key={i}
          className="absolute w-1 h-1 bg-purple-400/30 rounded-full"
          initial={{ x: p.x, y: p.y }}
          animate={{
            y: [p.y, '-100px'],
            opacity: [0, 1, 0],
          }}
          transition={{
            duration: p.dur,
            repeat: Infinity,
            ease: 'linear',
            delay: p.delay,
          }}
        />
      ))}
    </div>
  );
}

export default function Hero() {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTag, setActiveTag] = useState('');

  // 搜索功能
  const handleSearch = (e: { preventDefault: () => void }) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;

    const query = searchQuery.toLowerCase();
    const matchedModel = models.find(m =>
      m.name.toLowerCase().includes(query) ||
      m.company.toLowerCase().includes(query)
    );
    if (matchedModel) {
      document.getElementById('models')?.scrollIntoView({ behavior: 'smooth' });
    } else {
      document.getElementById('llm-intro')?.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // 点击热门标签
  const handleTagClick = (tag: string) => {
    setSearchQuery(tag);
    setActiveTag(tag);
    const query = tag.toLowerCase();

    if (query.includes('gpt') || query.includes('claude')) {
      document.getElementById('global-models')?.scrollIntoView({ behavior: 'smooth' });
    } else if (query.includes('agent')) {
      document.getElementById('agents')?.scrollIntoView({ behavior: 'smooth' });
    } else {
      document.getElementById('models')?.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // 键盘快捷键
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === '/' && document.activeElement?.tagName !== 'INPUT') {
        e.preventDefault();
        document.querySelector<HTMLInputElement>('input[type="text"]')?.focus();
      }
      if (e.key === 'Escape') {
        (document.activeElement as HTMLElement)?.blur();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* 赛博朋克背景 */}
      <div className="absolute inset-0 bg-gradient-to-br from-purple-950 via-blue-950 to-cyan-950">
        <CyberGrid />
        <FloatingParticles />

        {/* 动态光晕 */}
        <motion.div
          className="absolute top-1/4 left-1/4 w-[500px] h-[500px] bg-purple-600/20 rounded-full blur-[100px]"
          animate={{ x: [0, 50, 0], y: [0, -30, 0], scale: [1, 1.2, 1] }}
          transition={{ duration: 8, repeat: Infinity, ease: 'easeInOut' }}
        />
        <motion.div
          className="absolute bottom-1/4 right-1/4 w-[400px] h-[400px] bg-cyan-600/20 rounded-full blur-[100px]"
          animate={{ x: [0, -50, 0], y: [0, 30, 0], scale: [1.2, 1, 1.2] }}
          transition={{ duration: 10, repeat: Infinity, ease: 'easeInOut' }}
        />
        <motion.div
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-blue-600/10 rounded-full blur-[120px]"
          animate={{ scale: [1, 1.4, 1] }}
          transition={{ duration: 6, repeat: Infinity, ease: 'easeInOut' }}
        />

        {/* 发光线���装饰 */}
        <div className="absolute top-20 left-10 w-32 h-px bg-gradient-to-r from-purple-500 to-transparent opacity-50" />
        <div className="absolute top-40 right-20 w-20 h-px bg-gradient-to-l from-cyan-500 to-transparent opacity-50" />
        <div className="absolute bottom-40 left-1/4 w-24 h-px bg-gradient-to-r from-pink-500 to-transparent opacity-30" />
      </div>

      {/* CRT 扫描线效果 */}
      <div className="absolute inset-0 pointer-events-none opacity-[0.03] bg-[repeat-linear-gradient(0deg,transparent_50%,rgba(0,0,0,0.5)_50%)] bg-[length:100%_4px]" />

      {/* Content */}
      <div className="relative z-10 text-center px-4 max-w-5xl mx-auto">
        {/* Badge - 赛博风格 */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="mb-8"
        >
          <span className="inline-flex items-center gap-3 px-6 py-3 rounded-full bg-purple-500/10 backdrop-blur-md border border-purple-500/30 text-purple-300 text-sm">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-purple-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-purple-500"></span>
            </span>
            <span className="font-mono tracking-wider">AI MODELS /// CHINA</span>
            <span className="text-purple-500/50">///</span>
            <span className="text-white/60">2023-2025</span>
          </span>
        </motion.div>

        {/* Title - 带故障效果 */}
        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.5 }}
          className="text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-bold mb-6 leading-tight"
        >
          <span className="bg-gradient-to-r from-white via-purple-200 to-cyan-200 bg-clip-text text-transparent relative">
            AI 大模型
            {/* 故障装饰 */}
            <motion.span
              className="absolute -top-1 left-0 w-full h-full text-red-500/50"
              animate={{ opacity: [0, 0, 1, 0] }}
              transition={{ duration: 0.1, repeatDelay: 3, repeat: Infinity }}
            >
              AI 大模型
            </motion.span>
          </span>
          <br />
          <span className="bg-gradient-to-r from-purple-400 via-pink-400 to-cyan-400 bg-clip-text text-transparent">
            & Agent 全景图谱
          </span>
        </motion.h1>

        {/* Description */}
        <motion.p
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.7 }}
          className="text-xl md:text-2xl text-gray-300 mb-10 max-w-3xl mx-auto leading-relaxed"
        >
          <span className="text-purple-300">&gt;</span> 从大模型原理到 Agent 架构，从国内领先到全球顶尖
          <br className="hidden md:block" />
          <span className="text-cyan-300">&gt;</span> 一站了解人工智能最前沿的技术与生态
        </motion.p>

        {/* Search Bar - 赛博风格 */}
        <motion.form
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.8 }}
          onSubmit={handleSearch}
          className="max-w-xl mx-auto mb-12"
        >
          <div className="relative group">
            {/* 发光边框 */}
            <div className="absolute -inset-0.5 bg-gradient-to-r from-purple-500 via-cyan-500 to-purple-500 rounded-full opacity-30 group-hover:opacity-60 blur transition-all duration-500" />

            <div className="relative flex items-center">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="[ 搜索模型、Agent或技术专题... ]"
                className="w-full px-6 py-4 pl-12 pr-24 bg-black/40 backdrop-blur-md border border-purple-500/30 rounded-full text-purple-100 placeholder-purple-500/50 focus:outline-none focus:border-purple-400 focus:bg-black/60 transition-all font-mono"
              />
              <button
                type="submit"
                className="absolute right-2 top-1/2 -translate-y-1/2 px-5 py-2 bg-gradient-to-r from-purple-600 to-cyan-600 rounded-full text-white font-medium hover:shadow-[0_0_20px_rgba(139,92,246,0.5)] transition-all font-mono text-sm"
              >
                EXEC
              </button>
              <span className="absolute left-5 top-1/2 -translate-y-1/2 text-purple-500/70">&gt;</span>
            </div>
          </div>
        </motion.form>

        {/* Hot Search Tags - 终端风格 */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.9 }}
          className="flex flex-wrap items-center justify-center gap-2 mb-10"
        >
          <span className="text-purple-500/50 text-xs font-mono mr-2">// HOT:</span>
          {hotSearchTags.map((tag) => (
            <button
              key={tag.label}
              onClick={() => handleTagClick(tag.label)}
              className={`px-3 py-1 text-xs rounded font-mono transition-all ${
                activeTag === tag.label
                  ? 'bg-purple-600 text-white shadow-[0_0_10px_rgba(139,92,246,0.5)]'
                  : 'bg-purple-500/10 text-purple-300/70 hover:bg-purple-500/20 hover:text-purple-200 border border-purple-500/20'
              }`}
            >
              {tag.label}
            </button>
          ))}
        </motion.div>

        {/* Stats - 仪表盘风格 */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.95 }}
          className="flex flex-wrap items-center justify-center gap-4 mb-12"
        >
          {stats.map((stat) => (
            <motion.div
              key={stat.label}
              className="relative group"
              whileHover={{ scale: 1.05 }}
            >
              <div className="absolute -inset-0.5 bg-gradient-to-r from-purple-500/50 to-cyan-500/50 rounded-full opacity-0 group-hover:opacity-30 blur transition-all" />
              <div className="relative flex items-center gap-3 px-5 py-3 bg-black/30 backdrop-blur-sm rounded-full border border-purple-500/20">
                <span className="text-xl">{stat.icon}</span>
                <span className="text-white font-bold text-xl font-mono">
                  <AnimatedNumber value={stat.count} />
                </span>
                <span className="text-purple-300/70 text-sm font-mono">{stat.label}</span>
              </div>
            </motion.div>
          ))}
        </motion.div>

        {/* Milestone Timeline */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 1.0 }}
          className="flex flex-wrap items-center justify-center gap-1 mb-12"
        >
          {milestones.map((m) => (
            <button
              key={m.year}
              onClick={() => document.getElementById('timeline')?.scrollIntoView({ behavior: 'smooth' })}
              className="group flex items-center gap-2 px-3 py-2 bg-black/20 hover:bg-purple-500/10 border border-purple-500/10 hover:border-purple-500/30 rounded text-xs transition-all"
            >
              <span className="text-purple-400 group-hover:text-white">{m.icon}</span>
              <span className="text-purple-500/60 font-mono">{m.year}</span>
              <span className="text-white/50 group-hover:text-white/80 hidden sm:inline">{m.event}</span>
            </button>
          ))}
        </motion.div>

        {/* Quick Actions - 命令风格 */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 1.05 }}
          className="flex items-center justify-center gap-3 mb-10"
        >
          {quickActions.map((action) => (
            <a
              key={action.label}
              href={action.href}
              className="flex items-center gap-2 px-4 py-2 bg-black/30 hover:bg-purple-500/20 border border-purple-500/20 hover:border-purple-500/40 rounded text-purple-300 hover:text-white text-sm transition-all font-mono"
            >
              <span>{action.icon}</span>
              <span>[ {action.label} ]</span>
            </a>
          ))}
        </motion.div>

        {/* Navigation Cards - 赛博风格 */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 1.1 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto pb-40"
        >
          {navCategories.map((category) => (
            <motion.a
              key={category.id}
              href={category.href}
              className="group relative overflow-hidden bg-black/40 backdrop-blur-sm border border-purple-500/20 rounded-2xl p-5 hover:bg-purple-500/10 hover:border-purple-500/50 transition-all duration-300 text-left"
              whileHover={{ scale: 1.02, x: 5 }}
            >
              {/* 角落装饰 */}
              <div className="absolute top-0 left-0 w-2 h-2 border-t-2 border-l-2 border-purple-500/50 opacity-0 group-hover:opacity-100 transition-opacity" />
              <div className="absolute top-0 right-0 w-2 h-2 border-t-2 border-r-2 border-purple-500/50 opacity-0 group-hover:opacity-100 transition-opacity" />
              <div className="absolute bottom-0 left-0 w-2 h-2 border-b-2 border-l-2 border-purple-500/50 opacity-0 group-hover:opacity-100 transition-opacity" />
              <div className="absolute bottom-0 right-0 w-2 h-2 border-b-2 border-r-2 border-purple-500/50 opacity-0 group-hover:opacity-100 transition-opacity" />

              {/* 渐变覆盖 */}
              <div className={`absolute inset-0 bg-gradient-to-br ${category.color} opacity-0 group-hover:opacity-10 transition-opacity duration-300`} />

              <div className="relative">
                <div className="text-3xl mb-3">{category.icon}</div>
                <div className="text-white font-semibold text-base mb-1 group-hover:text-purple-300 transition-colors font-mono">
                  {category.label}
                </div>
                <div className="text-gray-500 text-sm font-mono">{category.desc}</div>
              </div>
            </motion.a>
          ))}
        </motion.div>
      </div>

      {/* Scroll indicator - 科技风 */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.8 }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-3"
      >
        <motion.div
          animate={{ y: [0, 8, 0] }}
          transition={{ duration: 1.5, repeat: Infinity }}
          className="flex flex-col items-center"
        >
          <span className="text-purple-500/50 text-xs font-mono mb-2">// SCROLL DOWN</span>
          <div className="w-5 h-8 border border-purple-500/30 rounded flex items-start justify-center p-1">
            <motion.div
              className="w-1 h-2 bg-purple-500 rounded"
              animate={{ y: [0, 12, 0] }}
              transition={{ duration: 1.5, repeat: Infinity }}
            />
          </div>
        </motion.div>
      </motion.div>
    </section>
  );
}