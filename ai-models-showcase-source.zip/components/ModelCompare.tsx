'use client';

import { motion } from 'framer-motion';
import { models } from '@/data/models';

export default function ModelCompare() {
  const capabilities = [
    { name: '代码能力', key: 'code' },
    { name: '中文理解', key: 'chinese' },
    { name: '数学推理', key: 'math' },
    { name: '多模态', key: 'multimodal' },
    { name: '长上下文', key: 'longcontext' },
    { name: '开源友好', key: 'opensource' },
  ];

  const scores: Record<string, Record<string, number>> = {
    deepseek: { code: 95, chinese: 90, math: 95, multimodal: 70, longcontext: 85, opensource: 98 },
    qwen: { code: 92, chinese: 95, math: 90, multimodal: 95, longcontext: 92, opensource: 95 },
    ernie: { code: 85, chinese: 98, math: 85, multimodal: 90, longcontext: 80, opensource: 60 },
    zhipu: { code: 90, chinese: 92, math: 88, multimodal: 85, longcontext: 85, opensource: 85 },
    kimi: { code: 85, chinese: 90, math: 88, multimodal: 75, longcontext: 98, opensource: 70 },
    doubao: { code: 80, chinese: 92, math: 82, multimodal: 88, longcontext: 80, opensource: 50 },
    spark: { code: 82, chinese: 95, math: 80, multimodal: 82, longcontext: 75, opensource: 55 },
    baichuan: { code: 85, chinese: 90, math: 85, multimodal: 78, longcontext: 80, opensource: 80 },
    minimax: { code: 78, chinese: 88, math: 78, multimodal: 90, longcontext: 75, opensource: 45 },
    yi: { code: 88, chinese: 88, math: 85, multimodal: 80, longcontext: 82, opensource: 92 },
    mimo: { code: 90, chinese: 88, math: 93, multimodal: 65, longcontext: 78, opensource: 95 },
    hunyuan: { code: 85, chinese: 93, math: 85, multimodal: 92, longcontext: 85, opensource: 75 },
    step: { code: 88, chinese: 90, math: 92, multimodal: 95, longcontext: 88, opensource: 70 },
    skylark: { code: 80, chinese: 90, math: 82, multimodal: 85, longcontext: 85, opensource: 65 },
    sensenova: { code: 82, chinese: 88, math: 80, multimodal: 93, longcontext: 78, opensource: 55 },
    minicpm: { code: 85, chinese: 86, math: 82, multimodal: 80, longcontext: 70, opensource: 96 },
  };

  return (
    <section id="compare" className="relative py-24 px-4">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            <span className="bg-gradient-to-r from-white to-gray-400 bg-clip-text text-transparent">
              能力对比
            </span>
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            各大模型在不同维度的能力表现（满分100）
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="overflow-x-auto"
        >
          <table className="w-full min-w-[800px]">
            <thead>
              <tr className="border-b border-white/10">
                <th className="text-left py-4 px-6 text-gray-400 font-medium">模型</th>
                {capabilities.map((cap) => (
                  <th key={cap.key} className="text-center py-4 px-4 text-gray-400 font-medium">
                    {cap.name}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {models.map((model, index) => (
                <motion.tr
                  key={model.id}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.05 }}
                  className="border-b border-white/5 hover:bg-white/5 transition-colors"
                >
                  <td className="py-4 px-6">
                    <div className="flex items-center gap-3">
                      <div
                        className="w-8 h-8 rounded-lg flex items-center justify-center text-white text-sm font-bold"
                        style={{ backgroundColor: model.color + '80' }}
                      >
                        {model.name.charAt(0)}
                      </div>
                      <div>
                        <div className="text-white font-medium">{model.name}</div>
                        <div className="text-xs text-gray-500">{model.company}</div>
                      </div>
                    </div>
                  </td>
                  {capabilities.map((cap) => (
                    <td key={cap.key} className="py-4 px-4">
                      <div className="flex flex-col items-center gap-2">
                        <div className="w-full bg-white/5 rounded-full h-2 max-w-[80px]">
                          <motion.div
                            initial={{ width: 0 }}
                            whileInView={{ width: `${scores[model.id][cap.key]}%` }}
                            viewport={{ once: true }}
                            transition={{ duration: 1, delay: 0.5 }}
                            className="h-full rounded-full"
                            style={{
                              background: `linear-gradient(90deg, ${model.color}, ${model.color}88)`,
                            }}
                          />
                        </div>
                        <span className="text-xs text-gray-400">
                          {scores[model.id][cap.key]}
                        </span>
                      </div>
                    </td>
                  ))}
                </motion.tr>
              ))}
            </tbody>
          </table>
        </motion.div>
      </div>
    </section>
  );
}
