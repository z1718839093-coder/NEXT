'use client';

import { motion } from 'framer-motion';

const timeline = [
  { date: '2023.03', title: 'ChatGPT 插件', desc: 'OpenAI 推出插件系统，Agent 概念兴起', color: '#10B981' },
  { date: '2023.03', title: '百度千帆', desc: '企业级大模型开发平台上线', color: '#2932E1' },
  { date: '2023.04', title: 'Dify 开源', desc: '开源 LLM 应用开发框架标杆', color: '#06B6D4' },
  { date: '2023.05', title: 'FlowiseAI', desc: 'LangChain 可视化编排工具开源', color: '#F97316' },
  { date: '2023.06', title: 'FastGPT', desc: '开源知识库问答平台发布', color: '#3B82F6' },
  { date: '2023.09', title: '魔搭 & 讯飞', desc: 'ModelScope 和讯飞推出 Agent 平台', color: '#E44D26' },
  { date: '2023.11', title: 'Coze 扣子', desc: '字节跳动推出可视化 Agent 平台', color: '#7C3AED' },
  { date: '2023.12', title: 'Coze 国际版', desc: 'coze.com 上线，接入全球大模型', color: '#A855F7' },
  { date: '2024.01', title: '百炼 & RAGFlow', desc: '阿里百炼发布，RAGFlow 开源', color: '#FF6A00' },
  { date: '2024.02', title: 'MaxKB 开源', desc: '部署最简的开源知识库平台', color: '#8B5CF6' },
  { date: '2024.03', title: '元器 & 智谱', desc: '腾讯元器发布，智谱推出 Agent', color: '#00A6FB' },
  { date: '2024.05', title: '混元智能体', desc: '腾讯打通微信生态的 Agent 平台', color: '#07C160' },
  { date: '2024.06', title: 'Coze 工作流', desc: '可视化工作流编排全面升级', color: '#7C3AED' },
  { date: '2025.01', title: 'Agent 生态爆发', desc: '百花齐放，开源与商业并进', color: '#7C3AED' },
];

export default function AgentTimeline() {
  return (
    <section id="agent-timeline" className="relative py-24 px-4">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            <span className="bg-gradient-to-r from-white to-gray-400 bg-clip-text text-transparent">
              Agent 发展历程
            </span>
          </h2>
          <p className="text-gray-400 text-lg">
            AI Agent 平台的演进之路（2023 - 2025）
          </p>
        </motion.div>

        {/* Horizontal scrollable timeline */}
        <div className="relative overflow-x-auto pb-8 -mx-4 px-4">
          <div className="relative min-w-max">
            {/* Horizontal line */}
            <div className="absolute top-[21px] left-0 right-0 h-[2px] bg-gradient-to-r from-purple-500 via-violet-500 to-cyan-500" />

            {/* Timeline items */}
            <div className="flex gap-0">
              {timeline.map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.08 }}
                  className="relative flex flex-col items-center w-[140px] flex-shrink-0"
                >
                  {/* Dot */}
                  <motion.div
                    whileInView={{ scale: [0, 1.3, 1] }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.08 + 0.2 }}
                    className="w-[42px] h-[42px] rounded-full flex items-center justify-center mb-4 relative z-10"
                    style={{ backgroundColor: item.color + '20' }}
                  >
                    <div
                      className="w-3 h-3 rounded-full"
                      style={{ backgroundColor: item.color }}
                    />
                  </motion.div>

                  {/* Content below line */}
                  <div className="text-center px-2">
                    <div className="text-xs text-gray-500 mb-1 font-mono">{item.date}</div>
                    <h3 className="text-sm font-semibold text-white mb-1">{item.title}</h3>
                    <p className="text-xs text-gray-400 leading-relaxed">{item.desc}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>

        {/* Scroll hint */}
        <div className="text-center">
          <motion.div
            animate={{ x: [0, 10, 0] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="inline-flex items-center gap-2 text-xs text-gray-500"
          >
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
            </svg>
            横向滚动查看更多
          </motion.div>
        </div>
      </div>
    </section>
  );
}
