'use client';

import { motion } from 'framer-motion';
import { AIAgent } from '@/data/agents';

interface AgentCardProps {
  agent: AIAgent;
  index: number;
}

export default function AgentCard({ agent, index }: AgentCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6, delay: index * 0.1 }}
      whileHover={{ y: -10, scale: 1.02 }}
      className="group relative"
    >
      <div
        className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 blur-xl"
        style={{ backgroundColor: agent.color + '40' }}
      />

      <div className="relative bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 h-full hover:border-white/20 transition-all duration-500">
        {/* Header */}
        <div className="flex items-start justify-between mb-4">
          <div>
            <h3 className="text-xl font-bold text-white mb-1">{agent.name}</h3>
            <p className="text-sm text-gray-400">{agent.company}</p>
          </div>
          <div
            className="w-10 h-10 rounded-xl flex items-center justify-center text-white text-sm font-bold"
            style={{ backgroundColor: agent.color + '80' }}
          >
            {agent.name.charAt(0)}
          </div>
        </div>

        {/* Highlight */}
        <div
          className="inline-block px-3 py-1 rounded-full text-xs font-medium mb-4"
          style={{
            backgroundColor: agent.color + '20',
            color: agent.color,
          }}
        >
          {agent.highlight}
        </div>

        {/* Platform & Pricing */}
        <div className="mb-4 space-y-2">
          <div>
            <div className="text-xs text-gray-500 mb-1">平台类型</div>
            <div className="text-sm font-medium text-white">{agent.platform}</div>
          </div>
          <div>
            <div className="text-xs text-gray-500 mb-1">收费模式</div>
            <div className="text-sm font-medium text-white">{agent.pricing}</div>
          </div>
        </div>

        {/* Features */}
        <div className="space-y-2">
          <div className="text-xs text-gray-500">核心能力</div>
          <div className="flex flex-wrap gap-2">
            {agent.features.map((feature, i) => (
              <span
                key={i}
                className="px-2.5 py-1 bg-white/5 border border-white/10 rounded-lg text-xs text-gray-300"
              >
                {feature}
              </span>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="mt-6 pt-4 border-t border-white/5">
          <div className="flex items-center justify-between">
            <span className="text-xs text-gray-500">{agent.releaseDate}</span>
            <a
              href={agent.website}
              target="_blank"
              rel="noopener noreferrer"
              className="text-xs text-purple-400 hover:text-purple-300 transition-colors flex items-center gap-1"
            >
              官网
              <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
              </svg>
            </a>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
