'use client';

import { motion } from 'framer-motion';
import { agents } from '@/data/agents';

export default function AgentCompare() {
  const capabilities = [
    { name: '可视化编排', key: 'visual' },
    { name: '插件生态', key: 'plugins' },
    { name: '多模态支持', key: 'multimodal' },
    { name: '多渠道发布', key: 'channels' },
    { name: '开发者友好', key: 'developer' },
    { name: '性价比', key: 'pricing' },
  ];

  const scores: Record<string, Record<string, number>> = {
    coze: { visual: 95, plugins: 92, multimodal: 90, channels: 95, developer: 88, pricing: 85 },
    dify: { visual: 90, plugins: 85, multimodal: 78, channels: 75, developer: 98, pricing: 92 },
    fastgpt: { visual: 85, plugins: 75, multimodal: 70, channels: 72, developer: 90, pricing: 95 },
    bailian: { visual: 82, plugins: 80, multimodal: 92, channels: 78, developer: 85, pricing: 80 },
    qianfan: { visual: 78, plugins: 75, multimodal: 85, channels: 70, developer: 82, pricing: 75 },
    yuanqi: { visual: 85, plugins: 82, multimodal: 85, channels: 90, developer: 78, pricing: 82 },
    modelscope: { visual: 70, plugins: 88, multimodal: 80, channels: 60, developer: 92, pricing: 95 },
    spark: { visual: 80, plugins: 72, multimodal: 88, channels: 75, developer: 75, pricing: 78 },
    maxkb: { visual: 80, plugins: 70, multimodal: 68, channels: 65, developer: 88, pricing: 95 },
    ragflow: { visual: 72, plugins: 68, multimodal: 65, channels: 55, developer: 95, pricing: 95 },
    'hunyuan-agent': { visual: 85, plugins: 80, multimodal: 88, channels: 92, developer: 78, pricing: 80 },
    'zhipu-agent': { visual: 82, plugins: 85, multimodal: 85, channels: 72, developer: 92, pricing: 85 },
    'coze-global': { visual: 95, plugins: 90, multimodal: 88, channels: 92, developer: 90, pricing: 82 },
    'baichuan-agent': { visual: 75, plugins: 72, multimodal: 75, channels: 68, developer: 78, pricing: 82 },
    flowise: { visual: 88, plugins: 78, multimodal: 72, channels: 65, developer: 95, pricing: 98 },
  };

  return (
    <section id="agent-compare" className="relative py-24 px-4">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            <span className="bg-gradient-to-r from-white to-gray-400 bg-clip-text text-transparent">
              Agent 能力对比
            </span>
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            各 Agent 平台在不同维度的能力表现（满分100）
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="overflow-x-auto"
        >
          <table className="w-full min-w-[800px]">
            <thead>
              <tr className="border-b border-white/10">
                <th className="text-left py-4 px-6 text-gray-400 font-medium">平台</th>
                {capabilities.map((cap) => (
                  <th key={cap.key} className="text-center py-4 px-4 text-gray-400 font-medium">
                    {cap.name}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {agents.map((agent, index) => (
                <motion.tr
                  key={agent.id}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.05 }}
                  className="border-b border-white/5 hover:bg-white/5 transition-colors"
                >
                  <td className="py-4 px-6">
                    <div className="flex items-center gap-3">
                      <div
                        className="w-8 h-8 rounded-lg flex items-center justify-center text-white text-sm font-bold"
                        style={{ backgroundColor: agent.color + '80' }}
                      >
                        {agent.name.charAt(0)}
                      </div>
                      <div>
                        <div className="text-white font-medium">{agent.name}</div>
                        <div className="text-xs text-gray-500">{agent.company}</div>
                      </div>
                    </div>
                  </td>
                  {capabilities.map((cap) => (
                    <td key={cap.key} className="py-4 px-4">
                      <div className="flex flex-col items-center gap-2">
                        <div className="w-full bg-white/5 rounded-full h-2 max-w-[80px]">
                          <motion.div
                            initial={{ width: 0 }}
                            whileInView={{ width: `${scores[agent.id][cap.key]}%` }}
                            viewport={{ once: true }}
                            transition={{ duration: 1, delay: 0.5 }}
                            className="h-full rounded-full"
                            style={{
                              background: `linear-gradient(90deg, ${agent.color}, ${agent.color}88)`,
                            }}
                          />
                        </div>
                        <span className="text-xs text-gray-400">
                          {scores[agent.id][cap.key]}
                        </span>
                      </div>
                    </td>
                  ))}
                </motion.tr>
              ))}
            </tbody>
          </table>
        </motion.div>
      </div>
    </section>
  );
}
