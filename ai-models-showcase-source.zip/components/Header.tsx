'use client';

import { motion } from 'framer-motion';

export default function Header() {
  return (
    <motion.header
      initial={{ y: -100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.8 }}
      className="fixed top-0 w-full z-50 backdrop-blur-xl bg-black/60 border-b border-purple-500/30"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Logo */}
        <div className="flex items-center space-x-3">
          <div className="relative">
            {/* 发光效果 */}
            <div className="absolute -inset-1 bg-gradient-to-br from-purple-500 to-cyan-500 rounded-lg blur opacity-50 animate-pulse" />
            <div className="relative w-9 h-9 rounded-lg bg-gradient-to-br from-purple-600 to-cyan-600 flex items-center justify-center border border-purple-400/50">
              <span className="text-white font-bold text-sm font-mono">AI</span>
            </div>
          </div>
          <span className="text-white font-semibold text-lg font-mono tracking-wider">
            <span className="text-purple-400">&gt;</span> MODEL<span className="text-cyan-400">S</span>
            <span className="text-purple-500/50 text-sm ml-1">/// CHINA</span>
          </span>
        </div>

        {/* 导航 */}
        <nav className="hidden md:flex items-center space-x-1">
          {[
            { href: '#llm-intro', label: '[ 科普专栏 ]' },
            { href: '#models', label: '[ 国内模型 ]' },
            { href: '#global-models', label: '[ 全球模型 ]' },
            { href: '#agents', label: '[ 国内Agent ]' },
            { href: '#global-agents', label: '[ 全球Agent ]' },
            { href: '#timeline', label: '[ 发展历程 ]' },
          ].map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="text-gray-400 hover:text-purple-300 transition-colors text-sm font-mono py-2 px-3 hover:bg-purple-500/10 rounded border border-transparent hover:border-purple-500/30"
            >
              {item.label}
            </a>
          ))}
        </nav>
      </div>

      {/* 底部装饰线 */}
      <div className="absolute bottom-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-purple-500/50 to-transparent" />
    </motion.header>
  );
}