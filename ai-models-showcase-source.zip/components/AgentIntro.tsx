'use client';

import { motion } from 'framer-motion';

const components = [
  {
    title: '感知',
    en: 'Perceive',
    color: '#7C3AED',
    desc: '接收用户输入、环境信号和工具返回结果，理解当前上下文与任务状态。',
    icon: (
      <svg className="w-7 h-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
      </svg>
    ),
  },
  {
    title: '规划',
    en: 'Plan',
    color: '#06B6D4',
    desc: '将复杂任务拆解为可执行的子步骤，制定执行策略，支持反思和自我纠错。',
    icon: (
      <svg className="w-7 h-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" />
      </svg>
    ),
  },
  {
    title: '执行',
    en: 'Act',
    color: '#10B981',
    desc: '调用外部工具、API、代码执行器等，与真实世界交互，完成具体任务。',
    icon: (
      <svg className="w-7 h-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.066 2.573c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.573 1.066c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.066-2.573c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
      </svg>
    ),
  },
  {
    title: '记忆',
    en: 'Remember',
    color: '#F59E0B',
    desc: '短期记忆保持当前会话上下文，长期记忆存储知识库和历史经验，支持持续学习。',
    icon: (
      <svg className="w-7 h-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
      </svg>
    ),
  },
];

const differences = [
  { aspect: '核心驱动力', traditional: '预定义规则与逻辑', agent: '大语言模型的推理能力' },
  { aspect: '决策方式', traditional: 'if-else 分支或有限状态机', agent: 'LLM 动态推理与规划' },
  { aspect: '工具使用', traditional: '硬编码 API 调用', agent: 'LLM 自主决定何时调用何种工具' },
  { aspect: '适应能力', traditional: '仅处理预设场景', agent: '可应对开放域未知任务' },
  { aspect: '自我纠错', traditional: '依赖人工干预', agent: '可通过反思自动修正' },
];

export default function AgentIntro() {
  return (
    <section id="agent-intro" className="relative py-24 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            <span className="bg-gradient-to-r from-white to-gray-400 bg-clip-text text-transparent">
              什么是 Agent AI
            </span>
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            Agent = LLM（大脑）+ 记忆 + 工具 + 规划，让 AI 从「问答」走向「行动」
          </p>
        </motion.div>

        {/* Formula */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="flex flex-wrap items-center justify-center gap-3 mb-16 text-lg md:text-xl"
        >
          <span className="px-4 py-2 bg-purple-500/10 border border-purple-500/20 rounded-xl text-purple-300 font-semibold">LLM</span>
          <span className="text-gray-500">+</span>
          <span className="px-4 py-2 bg-amber-500/10 border border-amber-500/20 rounded-xl text-amber-300 font-semibold">记忆</span>
          <span className="text-gray-500">+</span>
          <span className="px-4 py-2 bg-green-500/10 border border-green-500/20 rounded-xl text-green-300 font-semibold">工具</span>
          <span className="text-gray-500">+</span>
          <span className="px-4 py-2 bg-cyan-500/10 border border-cyan-500/20 rounded-xl text-cyan-300 font-semibold">规划</span>
          <span className="text-gray-500">=</span>
          <span className="px-5 py-2 bg-gradient-to-r from-purple-500/20 to-cyan-500/20 border border-white/20 rounded-xl text-white font-bold">
            Agent AI
          </span>
        </motion.div>

        {/* Component cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {components.map((comp, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.12 }}
              className="group bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 hover:border-white/20 transition-all duration-300 text-center"
            >
              <div
                className="w-16 h-16 rounded-2xl mx-auto mb-4 flex items-center justify-center transition-transform group-hover:scale-110"
                style={{ backgroundColor: comp.color + '15', color: comp.color }}
              >
                {comp.icon}
              </div>
              <h3 className="text-lg font-bold text-white mb-1">{comp.title}</h3>
              <div className="text-xs text-gray-500 mb-3">{comp.en}</div>
              <p className="text-sm text-gray-400 leading-relaxed">{comp.desc}</p>
            </motion.div>
          ))}
        </div>

        {/* Differences table */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <h3 className="text-2xl font-bold text-white text-center mb-8">
            Agent AI <span className="text-gray-500">vs</span> 传统 AI
          </h3>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[600px]">
              <thead>
                <tr className="border-b border-white/10">
                  <th className="text-left py-4 px-6 text-gray-400 font-medium">对比维度</th>
                  <th className="text-center py-4 px-4 text-gray-400 font-medium">传统 AI 应用</th>
                  <th className="text-center py-4 px-4 text-gray-400 font-medium">Agent AI</th>
                </tr>
              </thead>
              <tbody>
                {differences.map((diff, index) => (
                  <motion.tr
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.05 }}
                    className="border-b border-white/5 hover:bg-white/5 transition-colors"
                  >
                    <td className="py-4 px-6 text-white font-medium">{diff.aspect}</td>
                    <td className="py-4 px-4 text-center text-gray-400 text-sm">{diff.traditional}</td>
                    <td className="py-4 px-4 text-center text-cyan-300 text-sm font-medium">{diff.agent}</td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        </motion.div>
      </div>

      <div className="absolute bottom-0 right-1/4 w-[600px] h-[600px] bg-purple-500/5 rounded-full blur-3xl -z-10" />
    </section>
  );
}
