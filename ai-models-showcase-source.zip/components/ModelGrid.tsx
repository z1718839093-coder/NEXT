'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { models } from '@/data/models';
import ModelCard from './ModelCard';

export default function ModelGrid() {
  const [companyFilter, setCompanyFilter] = useState('全部');
  const [opensourceFilter, setOpensourceFilter] = useState('全部');

  // 获取所有公司列表
  const companies = ['全部', ...new Set(models.map(m => m.company))];

  // 筛选模型
  const filteredModels = models.filter(model => {
    if (companyFilter !== '全部' && model.company !== companyFilter) return false;
    const isOpensource = model.features.includes('开源免费') || model.features.includes('开源');
    if (opensourceFilter === '开源' && !isOpensource) return false;
    if (opensourceFilter === '闭源' && isOpensource) return false;
    return true;
  });

  return (
    <section id="models" className="relative py-24 px-4">
      {/* 背景装饰 */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute inset-0 bg-[linear-gradient(rgba(139,92,246,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(139,92,246,0.02)_1px,transparent_1px)] bg-[size:50px_50px]" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-purple-600/5 rounded-full blur-3xl" />
      </div>

      <div className="max-w-7xl mx-auto relative">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-purple-500/10 border border-purple-500/30 rounded-full mb-4">
            <span className="w-2 h-2 bg-purple-500 rounded-full animate-pulse" />
            <span className="text-purple-400 text-xs font-mono">/// DOMESTIC MODELS</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            <span className="bg-gradient-to-r from-white via-purple-200 to-cyan-200 bg-clip-text text-transparent font-mono">
              {'>'} 国内主流大模型
            </span>
          </h2>
          <p className="text-gray-400 text-base max-w-2xl mx-auto font-mono leading-relaxed">
            {'>'} 从 DeepSeek 到通义千问，从文心一言到 Kimi<br/>
            {'>'} 每一个大模型都在各自的赛道上绽放光芒
          </p>
        </motion.div>

        {/* 筛选栏 - 终端风格 */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="flex flex-wrap items-center justify-center gap-3 mb-12"
        >
          {/* 公司筛选 */}
          <div className="flex items-center gap-2">
            <span className="text-purple-500/50 text-xs font-mono">// FILTER:</span>
            <select
              value={companyFilter}
              onChange={(e) => setCompanyFilter(e.target.value)}
              className="px-4 py-2 bg-black/40 border border-purple-500/30 rounded-lg text-purple-100 font-mono text-sm focus:outline-none focus:border-purple-400 focus:shadow-[0_0_10px_rgba(139,92,246,0.3)]"
            >
              {companies.map((company) => (
                <option key={company} value={company} className="bg-black text-purple-100">
                  {company}
                </option>
              ))}
            </select>
          </div>

          {/* 开源/闭源筛选 */}
          <div className="flex bg-black/40 border border-purple-500/20 rounded-lg overflow-hidden">
            {['全部', '开源', '闭源'].map((item) => (
              <button
                key={item}
                onClick={() => setOpensourceFilter(item)}
                className={`px-4 py-2 text-sm font-mono transition-all ${
                  opensourceFilter === item
                    ? 'bg-purple-600 text-white shadow-[0_0_15px_rgba(139,92,246,0.4)]'
                    : 'text-purple-300/70 hover:text-white hover:bg-purple-500/20'
                }`}
              >
                [{item}]
              </button>
            ))}
          </div>

          {/* 结果计数 */}
          <div className="px-4 py-2 bg-black/40 border border-purple-500/20 rounded-lg">
            <span className="text-purple-300 font-mono text-sm">
              TOTAL: <span className="text-white font-bold">{filteredModels.length}</span> MODELS
            </span>
          </div>
        </motion.div>

        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
          {filteredModels.map((model, index) => (
            <ModelCard key={model.id} model={model} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
}