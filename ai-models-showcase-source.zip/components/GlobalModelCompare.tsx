'use client';

import { motion } from 'framer-motion';
import { globalModels } from '@/data/globalModels';

export default function GlobalModelCompare() {
  const capabilities = [
    { name: '代码能力', key: 'code' },
    { name: '多语言', key: 'multilang' },
    { name: '数学推理', key: 'math' },
    { name: '多模态', key: 'multimodal' },
    { name: '长上下文', key: 'longcontext' },
    { name: '安全对齐', key: 'safety' },
  ];

  const scores: Record<string, Record<string, number>> = {
    gpt4o: { code: 95, multilang: 95, math: 92, multimodal: 98, longcontext: 85, safety: 88 },
    claude: { code: 97, multilang: 93, math: 95, multimodal: 88, longcontext: 98, safety: 98 },
    gemini: { code: 92, multilang: 95, math: 93, multimodal: 96, longcontext: 99, safety: 90 },
    llama: { code: 90, multilang: 90, math: 88, multimodal: 85, longcontext: 88, safety: 82 },
    mistral: { code: 88, multilang: 92, math: 85, multimodal: 75, longcontext: 82, safety: 85 },
    grok: { code: 85, multilang: 85, math: 90, multimodal: 80, longcontext: 78, safety: 70 },
    cohere: { code: 82, multilang: 90, math: 80, multimodal: 65, longcontext: 85, safety: 88 },
    phi: { code: 85, multilang: 80, math: 92, multimodal: 60, longcontext: 65, safety: 82 },
    dbRX: { code: 82, multilang: 82, math: 78, multimodal: 60, longcontext: 75, safety: 80 },
    'amazon-nova': { code: 80, multilang: 85, math: 78, multimodal: 82, longcontext: 80, safety: 90 },
  };

  return (
    <section id="global-compare" className="relative py-24 px-4">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            <span className="bg-gradient-to-r from-white to-gray-400 bg-clip-text text-transparent">
              全球大模型能力对比
            </span>
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            全球顶尖模型在不同维度的能力表现（满分100）
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="overflow-x-auto"
        >
          <table className="w-full min-w-[800px]">
            <thead>
              <tr className="border-b border-white/10">
                <th className="text-left py-4 px-6 text-gray-400 font-medium">模型</th>
                {capabilities.map((cap) => (
                  <th key={cap.key} className="text-center py-4 px-4 text-gray-400 font-medium">
                    {cap.name}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {globalModels.map((model, index) => (
                <motion.tr
                  key={model.id}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.05 }}
                  className="border-b border-white/5 hover:bg-white/5 transition-colors"
                >
                  <td className="py-4 px-6">
                    <div className="flex items-center gap-3">
                      <div
                        className="w-8 h-8 rounded-lg flex items-center justify-center text-white text-sm font-bold"
                        style={{ backgroundColor: model.color + '80' }}
                      >
                        {model.name.charAt(0)}
                      </div>
                      <div>
                        <div className="text-white font-medium">{model.name}</div>
                        <div className="text-xs text-gray-500">{model.company}</div>
                      </div>
                    </div>
                  </td>
                  {capabilities.map((cap) => (
                    <td key={cap.key} className="py-4 px-4">
                      <div className="flex flex-col items-center gap-2">
                        <div className="w-full bg-white/5 rounded-full h-2 max-w-[80px]">
                          <motion.div
                            initial={{ width: 0 }}
                            whileInView={{ width: `${scores[model.id][cap.key]}%` }}
                            viewport={{ once: true }}
                            transition={{ duration: 1, delay: 0.5 }}
                            className="h-full rounded-full"
                            style={{
                              background: `linear-gradient(90deg, ${model.color}, ${model.color}88)`,
                            }}
                          />
                        </div>
                        <span className="text-xs text-gray-400">
                          {scores[model.id][cap.key]}
                        </span>
                      </div>
                    </td>
                  ))}
                </motion.tr>
              ))}
            </tbody>
          </table>
        </motion.div>
      </div>
    </section>
  );
}
