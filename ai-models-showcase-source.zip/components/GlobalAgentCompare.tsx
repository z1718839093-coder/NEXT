'use client';

import { motion } from 'framer-motion';
import { globalAgents } from '@/data/globalAgents';

export default function GlobalAgentCompare() {
  const capabilities = [
    { name: '生态集成', key: 'ecosystem' },
    { name: '多模型支持', key: 'multimodel' },
    { name: '编排能力', key: 'orchestration' },
    { name: '生产就绪', key: 'production' },
    { name: '开发者体验', key: 'developer' },
    { name: '开源友好', key: 'opensource' },
  ];

  const scores: Record<string, Record<string, number>> = {
    'openai-assistants': { ecosystem: 95, multimodel: 40, orchestration: 78, production: 92, developer: 90, opensource: 30 },
    'claude-agents': { ecosystem: 85, multimodel: 50, orchestration: 82, production: 90, developer: 92, opensource: 60 },
    langchain: { ecosystem: 90, multimodel: 98, orchestration: 92, production: 85, developer: 88, opensource: 98 },
    crewai: { ecosystem: 70, multimodel: 90, orchestration: 95, production: 78, developer: 85, opensource: 95 },
    autogen: { ecosystem: 75, multimodel: 92, orchestration: 88, production: 72, developer: 80, opensource: 98 },
    'bedrock-agents': { ecosystem: 88, multimodel: 90, orchestration: 75, production: 95, developer: 78, opensource: 20 },
    'vertex-ai': { ecosystem: 85, multimodel: 75, orchestration: 78, production: 92, developer: 80, opensource: 25 },
    'semantic-kernel': { ecosystem: 82, multimodel: 80, orchestration: 80, production: 88, developer: 82, opensource: 90 },
    autogpt: { ecosystem: 60, multimodel: 85, orchestration: 70, production: 55, developer: 75, opensource: 98 },
    haystack: { ecosystem: 75, multimodel: 92, orchestration: 85, production: 90, developer: 85, opensource: 95 },
  };

  return (
    <section id="global-agent-compare" className="relative py-24 px-4">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            <span className="bg-gradient-to-r from-white to-gray-400 bg-clip-text text-transparent">
              全球 Agent 平台能力对比
            </span>
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            全球主流 Agent 框架在不同维度的能力表现（满分100）
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="overflow-x-auto"
        >
          <table className="w-full min-w-[800px]">
            <thead>
              <tr className="border-b border-white/10">
                <th className="text-left py-4 px-6 text-gray-400 font-medium">平台</th>
                {capabilities.map((cap) => (
                  <th key={cap.key} className="text-center py-4 px-4 text-gray-400 font-medium">
                    {cap.name}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {globalAgents.map((agent, index) => (
                <motion.tr
                  key={agent.id}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.05 }}
                  className="border-b border-white/5 hover:bg-white/5 transition-colors"
                >
                  <td className="py-4 px-6">
                    <div className="flex items-center gap-3">
                      <div
                        className="w-8 h-8 rounded-lg flex items-center justify-center text-white text-sm font-bold"
                        style={{ backgroundColor: agent.color + '80' }}
                      >
                        {agent.name.charAt(0)}
                      </div>
                      <div>
                        <div className="text-white font-medium">{agent.name}</div>
                        <div className="text-xs text-gray-500">{agent.company}</div>
                      </div>
                    </div>
                  </td>
                  {capabilities.map((cap) => (
                    <td key={cap.key} className="py-4 px-4">
                      <div className="flex flex-col items-center gap-2">
                        <div className="w-full bg-white/5 rounded-full h-2 max-w-[80px]">
                          <motion.div
                            initial={{ width: 0 }}
                            whileInView={{ width: `${scores[agent.id][cap.key]}%` }}
                            viewport={{ once: true }}
                            transition={{ duration: 1, delay: 0.5 }}
                            className="h-full rounded-full"
                            style={{
                              background: `linear-gradient(90deg, ${agent.color}, ${agent.color}88)`,
                            }}
                          />
                        </div>
                        <span className="text-xs text-gray-400">
                          {scores[agent.id][cap.key]}
                        </span>
                      </div>
                    </td>
                  ))}
                </motion.tr>
              ))}
            </tbody>
          </table>
        </motion.div>
      </div>
    </section>
  );
}
