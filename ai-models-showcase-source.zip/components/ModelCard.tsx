'use client';

import { motion } from 'framer-motion';
import { AIModel } from '@/data/models';

interface ModelCardProps {
  model: AIModel;
  index: number;
}

export default function ModelCard({ model, index }: ModelCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6, delay: index * 0.1 }}
      whileHover={{ y: -8, scale: 1.02 }}
      className="group relative"
    >
      {/* 发光背景 */}
      <div
        className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 blur-xl"
        style={{ backgroundColor: model.color + '40' }}
      />

      {/* 卡片主体 */}
      <div className="relative bg-black/40 backdrop-blur-xl border border-purple-500/20 rounded-2xl p-5 h-full hover:border-purple-500/50 transition-all duration-500">
        {/* 角落装饰 */}
        <div className="absolute top-0 left-0 w-3 h-3 border-t-2 border-l-2 border-purple-500/30 group-hover:border-purple-500 transition-colors" />
        <div className="absolute top-0 right-0 w-3 h-3 border-t-2 border-r-2 border-purple-500/30 group-hover:border-purple-500 transition-colors" />
        <div className="absolute bottom-0 left-0 w-3 h-3 border-b-2 border-l-2 border-purple-500/30 group-hover:border-purple-500 transition-colors" />
        <div className="absolute bottom-0 right-0 w-3 h-3 border-b-2 border-r-2 border-purple-500/30 group-hover:border-purple-500 transition-colors" />

        {/* Header */}
        <div className="flex items-start justify-between mb-4">
          <div>
            <h3 className="text-lg font-bold text-white mb-1 font-mono">{model.name}</h3>
            <p className="text-xs text-purple-400/70 font-mono">{model.company}</p>
          </div>
          <div
            className="w-10 h-10 rounded-lg flex items-center justify-center text-white text-sm font-bold font-mono border"
            style={{
              backgroundColor: model.color + '20',
              borderColor: model.color + '50',
              color: model.color
            }}
          >
            {model.name.charAt(0)}
          </div>
        </div>

        {/* Highlight - 终端风格 */}
        <div
          className="inline-block px-3 py-1.5 rounded text-xs font-mono mb-4 border"
          style={{
            backgroundColor: model.color + '10',
            borderColor: model.color + '30',
            color: model.color,
          }}
        >
          {'>'} {model.highlight}
        </div>

        {/* Parameters */}
        <div className="mb-4">
          <div className="text-xs text-purple-500/50 font-mono mb-1">/// PARAMETERS</div>
          <div className="text-base font-semibold text-white font-mono">{model.parameters}</div>
        </div>

        {/* Features */}
        <div className="space-y-2">
          <div className="text-xs text-purple-500/50 font-mono">/// FEATURES</div>
          <div className="flex flex-wrap gap-1.5">
            {model.features.map((feature, i) => (
              <span
                key={i}
                className="px-2 py-1 bg-purple-500/10 border border-purple-500/20 rounded text-xs text-purple-300/70 font-mono"
              >
                [{feature}]
              </span>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="mt-5 pt-4 border-t border-purple-500/20">
          <div className="flex items-center justify-between">
            <span className="text-xs text-purple-500/50 font-mono">{model.releaseDate}</span>
            <a
              href={model.website}
              target="_blank"
              rel="noopener noreferrer"
              className="text-xs text-purple-400 hover:text-purple-300 transition-colors flex items-center gap-1 font-mono hover:bg-purple-500/20 px-2 py-1 rounded border border-purple-500/20"
            >
              <span>VISIT</span>
              <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
              </svg>
            </a>
          </div>
        </div>
      </div>
    </motion.div>
  );
}