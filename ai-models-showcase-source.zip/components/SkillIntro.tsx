'use client';

import { motion } from 'framer-motion';

const whatIsCards = [
  {
    title: 'Skill 是什么',
    color: '#7C3AED',
    icon: (
      <svg className="w-7 h-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
      </svg>
    ),
    desc: 'Skill（技能）是 Agent 能力的模块化封装。每个 Skill 专注于完成一类特定任务，通过定义清晰的输入输出和行为指令，让 Agent 可以按需调用。Skill 将复杂的专业知识打包为可复用的能力单元。',
  },
  {
    title: '核心价值',
    color: '#06B6D4',
    icon: (
      <svg className="w-7 h-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
      </svg>
    ),
    desc: '① 能力复用：一次制作，所有 Agent 共享。② 边界清晰：每个 Skill 只做一类事，避免功能膨胀。③ 组合创新：多个 Skill 组合可实现复杂工作流。④ 持续进化：独立更新不影响其他技能。',
  },
];

const differences = [
  { aspect: '定义', tool: '单一功能的函数调用（如搜索、计算）', skill: '一组行为策略 + 工具 + 知识的封装', plugin: '外部服务的接入适配器' },
  { aspect: '粒度', tool: '原子级，单次调用', skill: '任务级，包含多步骤逻辑', plugin: '服务级，对接第三方API' },
  { aspect: '包含内容', tool: '函数签名 + 参数描述', skill: '指令模板 + 工具集 + 知识库 + 判断逻辑', plugin: 'API定义 + 认证配置' },
  { aspect: '典型示例', tool: 'Google搜索、计算器、天气查询', skill: '代码审查、数据分析报告、文档生成', plugin: 'Slack接入、GitHub集成、数据库连接' },
];

const skillTypes = [
  {
    name: '指令型 Skill',
    en: 'Instruction-based',
    color: '#7C3AED',
    desc: '通过精心设计的 Prompt 模板和行为规则指导 Agent 完成任务。不需要额外代码，纯靠指令质量驱动。',
    features: ['Prompt 模板驱动', '零代码实现', '适合创意/写作/分析', '易于维护和迭代'],
    example: '文案撰写、翻译风格、代码审查规则',
  },
  {
    name: '工具型 Skill',
    en: 'Tool-based',
    color: '#06B6D4',
    desc: '封装具体的 API 调用或代码执行能力。Agent 根据任务需求自动选择并调用对应的工具。',
    features: ['API/函数封装', '需要代码实现', '适合数据查询/计算', '可与外部系统交互'],
    example: '数据库查询、文件处理、API调用',
  },
  {
    name: '混合型 Skill',
    en: 'Hybrid',
    color: '#10B981',
    desc: '结合指令引导和工具调用。用指令定义行为策略，用工具实现具体操作，是最强大的 Skill 类型。',
    features: ['指令 + 工具结合', '支持多步骤编排', '适合复杂业务场景', '可包含条件判断'],
    example: '自动化测试、数据分析流水线、内容发布',
  },
];

const createSteps = [
  {
    step: '1',
    title: '定义 Skill 目标',
    desc: '明确这个 Skill 要解决什么问题，输入是什么，输出是什么。一个好的 Skill 聚焦于单一职责。',
    icon: ' ',
  },
  {
    step: '2',
    title: '编写行为指令',
    desc: '用清晰的 Prompt 描述 Skill 的行为规则、判断标准、输出格式。指令越精确，Agent 执行越稳定。',
    icon: '✏️',
  },
  {
    step: '3',
    title: '封装工具（可选）',
    desc: '如果需要调用外部 API 或执行代码，将工具封装为标准接口，包含参数描述和错误处理。',
    icon: '⚙️',
  },
  {
    step: '4',
    title: '测试与迭代',
    desc: '用多种场景测试 Skill 的表现，调整指令和工具参数，直到在边界情况下也能稳定工作。',
    icon: ' ',
  },
  {
    step: '5',
    title: '发布与共享',
    desc: '将 Skill 发布到平台市场或开源社区，让更多人复用你的能力，形成 Skill 生态。',
    icon: ' ',
  },
];

const platforms = [
  { name: 'Claude Code Skills', desc: 'Claude Code 的技能系统，通过 .claude/skills/ 目录定义', url: 'claude.ai/code' },
  { name: 'Coze 插件', desc: '扣子平台的插件市场，支持自定义插件发布', url: 'coze.cn' },
  { name: 'Dify 工具', desc: 'Dify 平台的自定义工具接入', url: 'dify.ai' },
  { name: 'LangChain Tools', desc: 'LangChain 生态的工具集成框架', url: 'langchain.com' },
  { name: 'OpenAI Function Calling', desc: 'OpenAI 的函数调用规范', url: 'openai.com' },
  { name: 'MCP (Model Context Protocol)', desc: 'Anthropic 提出的模型上下文开放协议', url: 'modelcontextprotocol.io' },
];

export default function SkillIntro() {
  return (
    <section id="skill-intro" className="relative py-24 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            <span className="bg-gradient-to-r from-white to-gray-400 bg-clip-text text-transparent">
              什么是 Skill
            </span>
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            Skill（技能）是 Agent 能力的模块化封装，让 AI 从「什么都会一点」变为「专精每个领域」
          </p>
        </motion.div>

        {/* What is Skill */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-16">
          {whatIsCards.map((card, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.15 }}
              className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-8 hover:border-white/20 transition-all duration-300"
            >
              <div className="flex items-center gap-4 mb-4">
                <div
                  className="w-14 h-14 rounded-xl flex items-center justify-center"
                  style={{ backgroundColor: card.color + '15', color: card.color }}
                >
                  {card.icon}
                </div>
                <h3 className="text-xl font-bold text-white">{card.title}</h3>
              </div>
              <p className="text-gray-400 leading-relaxed">{card.desc}</p>
            </motion.div>
          ))}
        </div>

        {/* Skill vs Tool vs Plugin */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-16"
        >
          <h3 className="text-2xl font-bold text-white text-center mb-8">
            Skill <span className="text-gray-500">vs</span> Tool <span className="text-gray-500">vs</span> Plugin
          </h3>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[700px]">
              <thead>
                <tr className="border-b border-white/10">
                  <th className="text-left py-4 px-6 text-gray-400 font-medium w-28">维度</th>
                  <th className="text-center py-4 px-4 text-gray-400 font-medium">Tool（工具）</th>
                  <th className="text-center py-4 px-4 text-purple-400 font-medium">Skill（技能）</th>
                  <th className="text-center py-4 px-4 text-gray-400 font-medium">Plugin（插件）</th>
                </tr>
              </thead>
              <tbody>
                {differences.map((diff, index) => (
                  <motion.tr
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.05 }}
                    className="border-b border-white/5 hover:bg-white/5 transition-colors"
                  >
                    <td className="py-4 px-6 text-white font-medium">{diff.aspect}</td>
                    <td className="py-4 px-4 text-center text-gray-400 text-sm">{diff.tool}</td>
                    <td className="py-4 px-4 text-center text-purple-300 text-sm font-medium">{diff.skill}</td>
                    <td className="py-4 px-4 text-center text-gray-400 text-sm">{diff.plugin}</td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        </motion.div>

        {/* Skill Types */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-16"
        >
          <h3 className="text-2xl font-bold text-white text-center mb-8">Skill 架构类型</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {skillTypes.map((type, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.15 }}
                className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-8 hover:border-white/20 transition-all duration-300"
              >
                <div className="flex items-center gap-3 mb-2">
                  <div
                    className="w-3 h-3 rounded-full"
                    style={{ backgroundColor: type.color }}
                  />
                  <h4 className="text-lg font-bold text-white">{type.name}</h4>
                </div>
                <div className="text-xs text-gray-500 mb-4">{type.en}</div>
                <p className="text-sm text-gray-400 mb-6 leading-relaxed">{type.desc}</p>
                <ul className="space-y-2 mb-6">
                  {type.features.map((f, i) => (
                    <li key={i} className="flex items-center gap-2 text-sm text-gray-300">
                      <div
                        className="w-1.5 h-1.5 rounded-full flex-shrink-0"
                        style={{ backgroundColor: type.color }}
                      />
                      {f}
                    </li>
                  ))}
                </ul>
                <div className="pt-4 border-t border-white/5">
                  <div className="text-xs text-gray-500 mb-1">典型场景</div>
                  <div className="text-sm text-gray-300">{type.example}</div>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* How to create */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-16"
        >
          <h3 className="text-2xl font-bold text-white text-center mb-8">如何制作一个 Skill</h3>
          <div className="space-y-6">
            {createSteps.map((step, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="flex gap-6 items-start"
              >
                <div className="flex-shrink-0 w-14 h-14 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center text-2xl">
                  {step.icon}
                </div>
                <div className="flex-1 bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 hover:border-white/20 transition-all duration-300">
                  <div className="flex items-center gap-3 mb-2">
                    <span className="px-2 py-0.5 bg-purple-500/20 text-purple-300 rounded text-xs font-bold">
                      STEP {step.step}
                    </span>
                    <h4 className="text-lg font-bold text-white">{step.title}</h4>
                  </div>
                  <p className="text-sm text-gray-400 leading-relaxed">{step.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Platforms */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <h3 className="text-2xl font-bold text-white text-center mb-8">主流 Skill 生态平台</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {platforms.map((p, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.08 }}
                className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-xl p-5 hover:border-white/20 transition-all duration-300"
              >
                <h4 className="text-white font-semibold mb-1">{p.name}</h4>
                <p className="text-xs text-gray-400 mb-2">{p.desc}</p>
                <span className="text-xs text-purple-400">{p.url}</span>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>

      <div className="absolute top-1/3 right-0 w-[500px] h-[500px] bg-purple-500/5 rounded-full blur-3xl -z-10" />
    </section>
  );
}
